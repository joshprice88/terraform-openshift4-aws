import json
import boto3
import os

def lambda_handler(event, context):
    instance_id = event['detail']['EC2InstanceId']
    ec2_client = boto3.client('ec2')
    elb_client = boto3.client('elbv2')
    
    ext_tg_arn = os.environ['API_EXT_TG']
    int_tg_arn = os.environ['API_INT_TG']
    
    ec2_describe = ec2_client.describe_instances(
        InstanceIds=[
            instance_id,
        ],
    )
    
    instance_ip = ec2_describe['Reservations'][0]['Instances'][0]['PrivateIpAddress']
    
    attach_instance_ext = elb_client.register_targets(
        TargetGroupArn=ext_tg_arn,
        Targets=[
            {
                'Id': instance_ip,
                'Port': 6443,
            },
        ]
    )
    
    attach_instance_ext = elb_client.register_targets(
        TargetGroupArn=int_tg_arn,
        Targets=[
            {
                'Id': instance_ip,
                'Port': 6443,
            },
        ]
    )
    
    
