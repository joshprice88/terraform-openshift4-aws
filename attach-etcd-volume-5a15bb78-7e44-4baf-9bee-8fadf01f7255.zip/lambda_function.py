import json
import boto3

def lambda_handler(event, context):
    print(event)
    asg_name = event['detail']['AutoScalingGroupName']
    instance_id = event['detail']['EC2InstanceId']
    instance_az = json.loads(event['detail']['NotificationMetadata'])['availability_zone']
    asg_client = boto3.client('autoscaling')
    ec2_client = boto3.client('ec2')
    cluster_tag = asg_client.describe_tags(
                Filters=[
                    {
                        'Name': 'auto-scaling-group',
                        'Values': [asg_name]
                    },
                    {
                        'Name': 'key',
                        'Values': ['cluster_id']
                    }
                ],
            )
    cluster_id_tag = 'kubernetes.io/cluster/' + cluster_tag['Tags'][0]['Value']
    
    volume = ec2_client.describe_volumes(
            Filters=[
                {
                    'Name': 'tag-key',
                    'Values': [
                        cluster_id_tag
                    ]
                },
                {
                    'Name': 'tag:etcd_volume',
                    'Values': ['true']
                },
                {
                    'Name': 'status',
                    'Values': [
                        'available'
                    ]
                },
                {
                    'Name': 'availability-zone',
                    'Values': [
                        instance_az
                    ]
                },
            ],
        )
    volume_id = volume['Volumes'][0]['VolumeId']
    
    attach = ec2_client.attach_volume(
            Device='/dev/sdf',
            InstanceId=instance_id,
            VolumeId=volume_id
        )

    